jQuery(document).ready(($)=>{

    // документ загружен!

    $('.element-1').lightGallery({

    });

});
