<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Document</title>

        <link rel="stylesheet" href="assets/css/lightgallery.min.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <script src="//code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="assets/js/lightgallery.min.js"></script>

        <script src="assets/js/script.js"></script>
    </head>
    <body>

        <div class="element-1">

            <a href="assets/img/1.jpg">
                <img src="assets/img/1.jpg" alt="">
            </a>


            <a href="assets/img/1.jpg">
                <img src="assets/img/1.jpg" alt="">
            </a>


            <a href="assets/img/1.jpg">
                <img src="assets/img/1.jpg" alt="">
            </a>


            <a href="assets/img/1.jpg">
                <img src="assets/img/1.jpg" alt="">
            </a>


            <a href="assets/img/1.jpg">
                <img src="assets/img/1.jpg" alt="">
            </a>


            <a href="assets/img/1.jpg">
                <img src="assets/img/1.jpg" alt="">
            </a>


            <a href="assets/img/1.jpg">
                <img src="assets/img/1.jpg" alt="">
            </a>


            <a href="assets/img/1.jpg">
                <img src="assets/img/1.jpg" alt="">
            </a>

        </div>

    </body>
</html>
